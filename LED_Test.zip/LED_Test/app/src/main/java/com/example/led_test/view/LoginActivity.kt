package com.example.led_test.view

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.led_test.R
import com.example.led_test.model.AuthModel
import com.example.led_test.present.AuthPresenter
import com.google.firebase.auth.FirebaseAuth
class LoginActivity : AppCompatActivity(), AuthModel.View {
    private lateinit var presenter: AuthModel.Presenter
    private lateinit var etEmail: EditText
    private lateinit var etPass: EditText
    private lateinit var btnLogin: Button
    private lateinit var btnGoToRegister: Button
    private lateinit var progressBar: ProgressBar
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (FirebaseAuth.getInstance().currentUser != null) {
            navigateToMain()
            return
        }
        setContentView(R.layout.activity_login)
        presenter = AuthPresenter(this)
        etEmail = findViewById(R.id.etEmail)
        etPass = findViewById(R.id.etPassword)
        btnLogin = findViewById(R.id.btnLogin)
        btnGoToRegister = findViewById(R.id.btnGoToRegister)
        progressBar = findViewById(R.id.progressBar)

        btnLogin.setOnClickListener {
            presenter.login(etEmail.text.toString(), etPass.text.toString())
        }
        btnGoToRegister.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }
    }
    override fun showLoading() {
        progressBar.visibility = View.VISIBLE
    }
    override fun hideLoading() {
        progressBar.visibility = View.GONE
    }
    override fun showError(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
    override fun navigateToMain() {
        val intent = Intent(this, MainActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }
}