package com.example.led_test.model

interface AuthModel {
    interface View {
        fun showLoading()
        fun hideLoading()
        fun showError(message: String)
        fun navigateToMain()
    }

    interface Presenter {
        fun register(email: String, pass: String, confirmPass: String)
        fun login(email: String, pass: String)
    }
}