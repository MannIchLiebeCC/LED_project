package com.example.led_test.present
import com.example.led_test.model.MainModel
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
class MainPresenter(
    private var view: MainModel.View?,
    private val auth: FirebaseAuth = FirebaseAuth.getInstance(),
    private val db: FirebaseDatabase = FirebaseDatabase.getInstance()
) : MainModel.Presenter {

    private val controlRef = db.getReference("control/led")
    private val logsRef = db.getReference("logs")

    override fun loadUserData() {
        val currentUser = auth.currentUser
        if (currentUser != null && !currentUser.email.isNullBeEmpty()) {
            view?.showUserEmail(currentUser.email!!)
        } else {
            view?.showUserEmail("Unknown User")
        }
    }

    override fun listenToLedState() {
        controlRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val state = snapshot.getValue(Int::class.java) ?: 0
                view?.updateLedUI(state == 1)
            }
            override fun onCancelled(error: DatabaseError) {
                view?.showError(error.message)
            }
        })
    }
    override fun toggleLed(turnOn: Boolean) {
        val stateInt = if (turnOn) 1 else 0
        val currentUser = auth.currentUser ?: return
        controlRef.setValue(stateInt).addOnFailureListener { e ->
            view?.showError(e.localizedMessage ?: "Failed to change state")
        }
        val isoFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }
        val formattedTimestamp = isoFormat.format(Date())
        val logEntry = mapOf(
            "action" to if (turnOn) "ON" else "OFF",
            "email" to currentUser.email,
            "source" to "Android App",
            "timestamp" to formattedTimestamp
        )
        logsRef.push().setValue(logEntry)
    }
    override fun logout() {
        auth.signOut()
        view?.navigateToLogin()
    }
}
private fun String?.isNullBeEmpty(): Boolean = this == null || this.isEmpty()