package com.example.led_test.view

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.led_test.model.MainModel
import com.example.led_test.R
import com.example.led_test.present.MainPresenter
import com.google.android.material.switchmaterial.SwitchMaterial

class MainActivity : AppCompatActivity(), MainModel.View {
    private lateinit var presenter: MainModel.Presenter
    private lateinit var tvUserEmail: TextView
    private lateinit var tvStatus: TextView
    private lateinit var switchLed: SwitchMaterial
    private lateinit var btnLogout: Button
    private var isProgrammaticChange = false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        presenter = MainPresenter(this)
        tvUserEmail = findViewById(R.id.tvUserEmail)
        tvStatus = findViewById(R.id.tvStatus)
        switchLed = findViewById(R.id.switchLed)
        btnLogout = findViewById(R.id.btnLogout)
        switchLed.setOnCheckedChangeListener { _, isChecked ->
            if (!isProgrammaticChange) {
                presenter.toggleLed(isChecked)
            }
        }
        btnLogout.setOnClickListener {
            presenter.logout()
        }
        presenter.loadUserData()
        presenter.listenToLedState()
    }

    override fun showUserEmail(email: String) {
        tvUserEmail.text = "Logged in as: $email"
    }

    override fun updateLedUI(isOn: Boolean) {
        isProgrammaticChange = true
        switchLed.isChecked = isOn
        tvStatus.text = if (isOn) "LED Status: ON" else "LED Status: OFF"
        isProgrammaticChange = false
    }

    override fun showError(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    override fun navigateToLogin() {
        val intent = Intent(this, LoginActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }
}