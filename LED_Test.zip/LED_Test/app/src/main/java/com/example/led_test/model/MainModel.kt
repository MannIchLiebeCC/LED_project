package com.example.led_test.model

interface MainModel {
    interface View {
        fun updateLedUI(isOn: Boolean)
        fun showUserEmail(email: String)
        fun showError(message: String)
        fun navigateToLogin()
    }

    interface Presenter {
        fun loadUserData()
        fun listenToLedState()
        fun toggleLed(turnOn: Boolean)
        fun logout()
    }
}