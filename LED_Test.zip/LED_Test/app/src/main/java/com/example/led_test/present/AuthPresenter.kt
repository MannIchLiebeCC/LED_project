package com.example.led_test.present
import com.example.led_test.model.AuthModel
import com.google.firebase.auth.FirebaseAuth
class AuthPresenter(
    private var view: AuthModel.View?,
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
) : AuthModel.Presenter {
    override fun register(email: String, pass: String, confirmPass: String) {
        if (email.isBlank() || pass.isBlank() || confirmPass.isBlank()) {
            view?.showError("Please fill out all fields")
            return
        }
        if (pass != confirmPass) {
            view?.showError("Passwords do not match")
            return
        }
        if (pass.length < 6) {
            view?.showError("Password must be at least 6 characters")
            return
        }
        view?.showLoading()
        auth.createUserWithEmailAndPassword(email, pass)
            .addOnSuccessListener {
                view?.hideLoading()
                view?.navigateToMain()
            }
            .addOnFailureListener { e ->
                view?.hideLoading()
                view?.showError(e.localizedMessage ?: "Registration failed")
            }
    }
    override fun login(email: String, pass: String) {
        if (email.isBlank() || pass.isBlank()) {
            view?.showError("Please fill out all fields")
            return
        }
        view?.showLoading()
        auth.signInWithEmailAndPassword(email, pass)
            .addOnSuccessListener {
                view?.hideLoading()
                view?.navigateToMain()
            }
            .addOnFailureListener { e ->
                view?.hideLoading()
                view?.showError(e.localizedMessage ?: "Login failed")
            }
    }
}