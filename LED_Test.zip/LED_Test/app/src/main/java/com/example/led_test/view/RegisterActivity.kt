package com.example.led_test.view
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.led_test.R
import com.example.led_test.model.AuthModel
import com.example.led_test.present.AuthPresenter
class RegisterActivity : AppCompatActivity(), AuthModel.View {

    private lateinit var presenter: AuthModel.Presenter
    private lateinit var etEmail: EditText
    private lateinit var etPass: EditText
    private lateinit var etConfirmPass: EditText
    private lateinit var btnRegister: Button
    private lateinit var btnBackToLogin: Button
    private lateinit var progressBar: ProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        presenter = AuthPresenter(this)

        etEmail = findViewById(R.id.etRegEmail)
        etPass = findViewById(R.id.etRegPassword)
        etConfirmPass = findViewById(R.id.etRegConfirmPassword)
        btnRegister = findViewById(R.id.btnSubmitRegister)
        btnBackToLogin = findViewById(R.id.btnBackToLogin)
        progressBar = findViewById(R.id.regProgressBar)

        btnRegister.setOnClickListener {
            presenter.register(
                etEmail.text.toString(),
                etPass.text.toString(),
                etConfirmPass.text.toString()
            )
        }
        btnBackToLogin.setOnClickListener {
            finish()
        }
    }

    override fun showLoading() {
        progressBar.visibility = View.VISIBLE
    }
    override fun hideLoading() {
        progressBar.visibility = View.GONE
    }
    override fun showError(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
    override fun navigateToMain() {
        val intent = Intent(this, MainActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }
}